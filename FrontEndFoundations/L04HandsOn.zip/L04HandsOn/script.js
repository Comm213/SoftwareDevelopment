class Employee {
    constructor(name, salary, hireDate) {
        this.name = name;
        this.salary = salary;
        this.hireDate = hireDate;
    }

    getName() {
        console.log(this.name.toUpperCase());
    }

    getSalary() {
        console.log(this.salary);
    }

    getHireDate() {
        console.log(this.hireDate)
    }
}

class Manager extends Employee {
    constructor(descriptionOfJob, name, salary, hireDate) {
        super(name, salary, hireDate);
        this.descriptionOfJob = descriptionOfJob;
    }

    jobDescription() {
        console.log(this.name + " was hired on " + this.hireDate + " and make " + this.salary + " because she " + this.descriptionOfJob);
    }
}

class Designer extends Employee {
    constructor(experience, name, salary, hireDate) {
        super(name, salary, hireDate);
        this.experience = experience;
    }

    yearsExperience() {
        console.log(this.name + " was hired on " + this.hireDate + " and make " + this.salary + " because she had " + this.experience + " years experience.");
    }
}

class SalesAssociate extends Employee {
    constructor(degrees, name, salary, hireDate) {
        super(name, salary, hireDate);
        this.degrees = degrees;
    }

    degreeCompleted() {
        console.log(this.name + " was hired on " + this.hireDate + " and make " + this.salary + " because he got " + this.degrees + " degree");
    }
}

let Donna = new Manager("manages the sales staff", "Donna", 8000, "3/22/17");
let person = new Designer(5, "Anna", 10000, "3/10/2015");
let person2 = new SalesAssociate("baccalaureate", "Troy", 5500, "2/20/2018")

Donna.jobDescription();
person.yearsExperience();
person2.degreeCompleted();

